import React, { useState } from "react";
import NavbarSection from "./NavbarSection";
import Footer from "./Footer";
import { Container,Row,Col,Button } from "react-bootstrap";

const ContactPage = () => {
  const [data, setdata] = useState({
    name: "",
    number: "",
    email: "",
    subject: "",
  });
  const handleSubmit = (e) => {
    setdata({...data,[e.target.name]:e.target.value})
  };
  return (
    <>
      <NavbarSection />
      <Container>
        <Col>
          <Row>
            <h1>Send Us a Message</h1>
          </Row>
          <Row>
            <label htmlFor="name">Your Name</label>
          </Row>
          <Row>
            <input type="text" id="name" value={data.name} />
          </Row>
          <Row>
            <label htmlFor="number">Contact Number</label>
          </Row>
          <Row>
            <input type="text" id="number" value={data.number} />
          </Row>
          <Row>
            <label htmlFor="email">Your Email</label>
          </Row>
          <Row>
            <input type="email" id="email" value={data.email} />
          </Row>
          <Row>
            <label htmlFor="subject">Subject</label>
          </Row>
          <Row>
            <input type="text" id="subject" value={data.subject} />
          </Row>
          <Row>
            <Col>
              <Button variant="success">Success</Button>{" "}
            </Col>
            <Col>
              <Button variant="danger">Danger</Button>{" "}
            </Col>
          </Row>
        </Col>
        <Col>
          <Row>
            <Row>{ data.name}</Row>
            <Row>{data.number }</Row>
            <Row>{data.email }</Row>
            <Row>{data.subject}</Row>
          </Row>
        </Col>
      </Container>
      <Footer />
    </>
  );
};

export default ContactPage;
